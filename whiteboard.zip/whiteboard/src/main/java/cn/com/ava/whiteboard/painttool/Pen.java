package cn.com.ava.whiteboard.painttool;

import cn.com.ava.whiteboard.setting.PaintSetting;
import cn.com.ava.whiteboard.setting.PenSetting;

public class Pen extends PaintTool {

    public Pen(PaintSetting paintSetting) {
        super(paintSetting);
    }
}
