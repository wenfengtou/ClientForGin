package cn.com.ava.whiteboard.adapter;

public class PenColorBean {

    public int color;
    public int drawableId;

    public PenColorBean(int color, int drawableId) {
        this.color = color;
        this.drawableId = drawableId;
    }

}
