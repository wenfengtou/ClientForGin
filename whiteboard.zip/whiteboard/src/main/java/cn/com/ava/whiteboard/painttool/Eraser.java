package cn.com.ava.whiteboard.painttool;

import cn.com.ava.whiteboard.setting.PaintSetting;

public class Eraser extends PaintTool {

    public Eraser(PaintSetting paintSetting) {
        super(paintSetting);
    }

}
